package com.script.OOP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToUpperCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToUpperCaseApplication.class, args);
	}

}
