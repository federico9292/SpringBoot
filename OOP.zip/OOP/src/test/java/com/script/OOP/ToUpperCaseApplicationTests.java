package com.script.OOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToUpperCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
